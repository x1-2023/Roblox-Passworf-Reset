# Account Data Converter

Ứng dụng GUI đơn giản để chuyển đổi định dạng dữ liệu tài khoản từ `user:pass:mail:cookie` sang `user:pass:cookie`.

## Tính năng

- **Import file**: Import file .txt chứa dữ liệu tài khoản
- **Paste dữ liệu**: Dán trực tiếp dữ liệu vào ô input
- **Live conversion**: Tự động chuyển đổi khi nhập dữ liệu
- **Giao diện 2 bảng**: So sánh dữ liệu input và output
- **Dark theme**: Giao diện tối dễ nhìn

## Định dạng dữ liệu

**Input**: `user:pass:mail:cookie`

Ví dụ:
```
XxZoomRoguexX2024:Generated$1613458:mail@zohomail.com:_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.......
```

**Output**: `user:pass:cookie`

Ví dụ:
```
XxZoomRoguexX2024:Generated$1613458:_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.......
```

## Cách sử dụng

1. Chạy file `account_converter.py`
2. Import file .txt hoặc paste dữ liệu vào bảng trái
3. Nhấn "Convert" hoặc bật "Live Conversion"
4. Kết quả sẽ hiển thị ở bảng phải

## Cài đặt và chạy

### Chạy từ source code
```bash
python account_converter.py
```

### Build thành file .exe

1. Cài đặt PyInstaller:
```bash
pip install -r requirements.txt
```

2. Build exe:
```bash
pyinstaller --onefile --windowed --name="AccountConverter" account_converter.py
```

3. File exe sẽ được tạo trong thư mục `dist/`

### Build exe với icon (tùy chọn)
```bash
pyinstaller --onefile --windowed --name="AccountConverter" --icon=icon.ico account_converter.py
```

## Yêu cầu hệ thống

- Python 3.6+
- Windows 10/11
- Tkinter (có sẵn trong Python)

## Lưu ý

- Ứng dụng chỉ xử lý định dạng `user:pass:mail:cookie` với 4 phần tử
- Cookie có thể chứa dấu `:` và sẽ được giữ nguyên
- Dữ liệu không hợp lệ sẽ bị bỏ qua