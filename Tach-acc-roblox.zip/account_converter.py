import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading

class AccountConverter:
    def __init__(self, root):
        self.root = root
        self.root.title("Account Data Converter")
        self.root.geometry("1200x700")
        self.root.configure(bg='#2b2b2b')
        
        self.setup_ui()
        
    def setup_ui(self):
        # Main frame
        main_frame = tk.Frame(self.root, bg='#2b2b2b')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Title
        title_label = tk.Label(main_frame, text="Account Data Converter", 
                              font=('Arial', 16, 'bold'), 
                              bg='#2b2b2b', fg='white')
        title_label.pack(pady=(0, 20))
        
        # Control buttons frame
        control_frame = tk.Frame(main_frame, bg='#2b2b2b')
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Import button
        import_btn = tk.Button(control_frame, text="Import File", 
                              command=self.import_file,
                              bg='#4CAF50', fg='white', 
                              font=('Arial', 10, 'bold'),
                              padx=20, pady=5)
        import_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # Convert button
        convert_btn = tk.Button(control_frame, text="Convert", 
                               command=self.convert_data,
                               bg='#2196F3', fg='white', 
                               font=('Arial', 10, 'bold'),
                               padx=20, pady=5)
        convert_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # Clear button
        clear_btn = tk.Button(control_frame, text="Clear All", 
                             command=self.clear_all,
                             bg='#f44336', fg='white', 
                             font=('Arial', 10, 'bold'),
                             padx=20, pady=5)
        clear_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # Export button
        export_btn = tk.Button(control_frame, text="Export File", 
                              command=self.export_file,
                              bg='#FF9800', fg='white', 
                              font=('Arial', 10, 'bold'),
                              padx=20, pady=5)
        export_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # Live conversion checkbox
        self.live_var = tk.BooleanVar()
        live_check = tk.Checkbutton(control_frame, text="Live Conversion", 
                                   variable=self.live_var,
                                   command=self.toggle_live_conversion,
                                   bg='#2b2b2b', fg='white', 
                                   selectcolor='#2b2b2b',
                                   font=('Arial', 10))
        live_check.pack(side=tk.RIGHT)
        
        # Data frames
        data_frame = tk.Frame(main_frame, bg='#2b2b2b')
        data_frame.pack(fill=tk.BOTH, expand=True)
        
        # Left side - Input data
        left_frame = tk.Frame(data_frame, bg='#2b2b2b')
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        input_label = tk.Label(left_frame, text="Input Data (user:pass:mail:cookie)", 
                              font=('Arial', 12, 'bold'), 
                              bg='#2b2b2b', fg='white')
        input_label.pack(anchor=tk.W, pady=(0, 5))
        
        # Input text area with scrollbar
        input_frame = tk.Frame(left_frame)
        input_frame.pack(fill=tk.BOTH, expand=True)
        
        self.input_text = tk.Text(input_frame, wrap=tk.WORD, 
                                 bg='#3c3c3c', fg='white', 
                                 insertbackground='white',
                                 font=('Consolas', 9))
        input_scrollbar = tk.Scrollbar(input_frame, orient=tk.VERTICAL, 
                                      command=self.input_text.yview)
        self.input_text.configure(yscrollcommand=input_scrollbar.set)
        
        self.input_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        input_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Right side - Output data
        right_frame = tk.Frame(data_frame, bg='#2b2b2b')
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        output_label = tk.Label(right_frame, text="Output Data (user:pass:cookie)", 
                               font=('Arial', 12, 'bold'), 
                               bg='#2b2b2b', fg='white')
        output_label.pack(anchor=tk.W, pady=(0, 5))
        
        # Output text area with scrollbar
        output_frame = tk.Frame(right_frame)
        output_frame.pack(fill=tk.BOTH, expand=True)
        
        self.output_text = tk.Text(output_frame, wrap=tk.WORD, 
                                  bg='#3c3c3c', fg='white', 
                                  insertbackground='white',
                                  font=('Consolas', 9),
                                  state=tk.DISABLED)
        output_scrollbar = tk.Scrollbar(output_frame, orient=tk.VERTICAL, 
                                       command=self.output_text.yview)
        self.output_text.configure(yscrollcommand=output_scrollbar.set)
        
        self.output_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        output_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        status_bar = tk.Label(main_frame, textvariable=self.status_var, 
                             relief=tk.SUNKEN, anchor=tk.W,
                             bg='#404040', fg='white')
        status_bar.pack(fill=tk.X, side=tk.BOTTOM, pady=(10, 0))
        
        # Bind events for live conversion
        self.input_text.bind('<KeyRelease>', self.on_input_change)
        self.input_text.bind('<Button-1>', self.on_input_change)
        
    def import_file(self):
        file_path = filedialog.askopenfilename(
            title="Select account data file",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    content = file.read()
                    self.input_text.delete(1.0, tk.END)
                    self.input_text.insert(1.0, content)
                    self.status_var.set(f"Imported: {file_path}")
                    
                    if self.live_var.get():
                        self.convert_data()
                        
            except Exception as e:
                messagebox.showerror("Error", f"Failed to import file: {str(e)}")
                self.status_var.set("Import failed")
    
    def parse_account_line(self, line):
        line = line.strip()
        if not line:
            return None
            
        parts = line.split(':')
        if len(parts) >= 4:
            user = parts[0]
            password = parts[1]
            email = parts[2]
            cookie = ':'.join(parts[3:])  # Join remaining parts as cookie might contain ':'
            return f"{user}:{password}:{cookie}"
        return None
    
    def convert_data(self):
        input_data = self.input_text.get(1.0, tk.END).strip()
        if not input_data:
            self.status_var.set("No input data to convert")
            return
            
        lines = input_data.split('\n')
        converted_lines = []
        processed_count = 0
        
        for line in lines:
            converted = self.parse_account_line(line)
            if converted:
                converted_lines.append(converted)
                processed_count += 1
        
        # Update output
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(1.0, '\n'.join(converted_lines))
        self.output_text.config(state=tk.DISABLED)
        
        self.status_var.set(f"Converted {processed_count} accounts")
    
    def clear_all(self):
        self.input_text.delete(1.0, tk.END)
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete(1.0, tk.END)
        self.output_text.config(state=tk.DISABLED)
        self.status_var.set("Cleared all data")
    
    def toggle_live_conversion(self):
        if self.live_var.get():
            self.status_var.set("Live conversion enabled")
            self.convert_data()
        else:
            self.status_var.set("Live conversion disabled")
    
    def on_input_change(self, event=None):
        if self.live_var.get():
            # Use after_idle to avoid too frequent updates
            self.root.after_idle(self.convert_data)
    
    def export_file(self):
        output_data = self.output_text.get(1.0, tk.END).strip()
        if not output_data:
            messagebox.showwarning("Warning", "No converted data to export!")
            self.status_var.set("No data to export")
            return
        
        file_path = filedialog.asksaveasfilename(
            title="Save converted data",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialfile="converted_accounts.txt"
        )
        
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as file:
                    file.write(output_data)
                messagebox.showinfo("Success", f"File exported successfully!\n{file_path}")
                self.status_var.set(f"Exported: {file_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export file: {str(e)}")
                self.status_var.set("Export failed")

def main():
    root = tk.Tk()
    app = AccountConverter(root)
    root.mainloop()

if __name__ == "__main__":
    main()